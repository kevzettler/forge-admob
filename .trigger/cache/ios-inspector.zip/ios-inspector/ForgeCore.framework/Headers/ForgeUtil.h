//
//  ForgeUtil.h
//  ForgeCore
//
//  Created by Connor Dunn on 25/02/2013.
//  Copyright (c) 2013 Trigger Corp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ForgeUtil : NSObject

+ (BOOL) url:(NSString*)url matchesPattern:(NSString*)pattern;

@end
