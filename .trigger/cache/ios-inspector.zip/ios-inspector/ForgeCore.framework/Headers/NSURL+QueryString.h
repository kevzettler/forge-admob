//
//  NSURL+QueryString.h
//  Forge
//
//  Created by Connor Dunn on 21/02/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURL (QueryString)

- (NSDictionary *)queryAsDictionary;

@end
